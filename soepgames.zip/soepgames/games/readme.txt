﻿=== RealWorld classic Cursor Set ===

By: User (http://www.rw-designer.com/user/115294) mgjcueto1@gmail.com

Download: http://www.rw-designer.com/cursor-set/realworld-classic

Author's description:

This cursor set has missing the following cursor types:
Working in Background
Handwriting
Busy (Already have but forgot to upload)

This cursor pack is styled in the classic windows cursors, in RealWorld cursor presets

Note: This set has a continuation. Go check it out in my profile.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.